<?php

require '../../library/Slim/Slim.php';
\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();

$app->post('/user_details', 'user_details');
$app->post('/user_login', 'user_login');
$app->post('/Imogiscreen', 'Imogiscreen');
$app->post('/sharescreen', 'sharescreen');
$app->run(); 


function user_login() {
    try {
        $strFunctionName = __FUNCTION__;
        $version = 1;
        $response = array();

        $is_set_field = array('username','password');
        $not_empty_field = array('username','password');
     
        require_once '../../library/config.php';

        //if (!empty($token) && !empty($intUserId)) {
            $username = $_REQUEST['username'];
             $password = $_REQUEST['password'];
             $userexist = $objORM->executeQuery("SELECT count(1) as cnt FROM login  WHERE user_type = 0 and  username='$username' and password='$password' ", "cnt");
             if ($userexist == 1) {
                   $coach_details = $objORM->executeRow("SELECT * FROM `eventscreen` WHERE `status` = '1' ");
                $response['Eventscreen'] = $coach_details;
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
               // $response['success'] = array('code'=>200,'message'=>'successfully login');
             }else{
                 $response['error'] = $objCommon->error_code(34, $lang);
             }
              //echo json_encode($response, JSON_UNESCAPED_UNICODE);
            } catch (Exception $e) {
                $response['error'] = array("code" => 1, "status" => 400, "message" => $e->getMessage());
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            }
}


function user_details() {
    try {
        $strFunctionName = __FUNCTION__;
        $version = 1;
        $response = array();

        $is_set_field = array('username');
        $not_empty_field = array('username');
     
        require_once '../../library/config.php';

        //if (!empty($token) && !empty($intUserId)) {
            $username = $_REQUEST['username'];
            $user_exist = $objORM->executeQuery("SELECT count(1) as cnt FROM `login` WHERE `username` = '$username' AND `active` = '1' ", "cnt");
            if ($user_exist == 1) {
                 $coach_details = $objORM->executeRow("SELECT * FROM `login` WHERE `username` = '$username' ");
                $response['user_details'] = $coach_details;
                //$response['error'] = $objCommon->error_code(13, $lang);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            } else {
                $response['error'] = $objCommon->error_code(44, $lang);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            }
       // } //else {
            //$response['error'] = $objCommon->error_code(2, $lang);
           // echo json_encode($response, JSON_UNESCAPED_UNICODE);
       // }
    } catch (Exception $e) {
        $response['error'] = array("code" => 1, "status" => 400, "message" => $e->getMessage());
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
}


function Imogiscreen() {
 try {
        $strFunctionName = __FUNCTION__;
        $version = 1;
        $response = array();
        $is_set_field = array('username');
        $not_empty_field = array('username');
        require_once '../../library/config.php';
         $username = $_REQUEST['username'];
            $user_exist = $objORM->executeQuery("SELECT count(1) as cnt FROM `login` WHERE `username` = '$username' AND `active` = '1' ", "cnt");
            if ($user_exist == 1) {
                $coach_details = $objORM->executeRow("SELECT * FROM `imogiscreen`  WHERE `status` = '1'");
                $response['Imogiscreen'] = $coach_details;
                //$response['error'] = $objCommon->error_code(13, $lang);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            }else{
                $response['error'] = $objCommon->error_code(44, $lang);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            }
    } 
    catch (Exception $e) 
    {
        $response['error'] = array("code" => 1, "status" => 400, "message" => $e->getMessage());
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
}

function sharescreen() {
 try {
        $strFunctionName = __FUNCTION__;
        $version = 1;
        $response = array();
        $is_set_field = array('username');
        $not_empty_field = array('username');
        require_once '../../library/config.php';
         $username = $_REQUEST['username'];
            $user_exist = $objORM->executeQuery("SELECT count(1) as cnt FROM `login` WHERE `username` = '$username' AND `active` = '1' ", "cnt");
            if ($user_exist == 1) {
                $coach_details = $objORM->executeRow("SELECT * FROM `sharescreen`  WHERE `status` = '1'");
                $response['sharescreen'] = $coach_details;
                //$response['error'] = $objCommon->error_code(13, $lang);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            }else{
                $response['error'] = $objCommon->error_code(44, $lang);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            }
    } 
    catch (Exception $e) 
    {
        $response['error'] = array("code" => 1, "status" => 400, "message" => $e->getMessage());
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
}
?>