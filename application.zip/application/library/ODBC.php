<?php

class clsODBC {

    var $conn;

    public function connection() {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "exioms_motodaft";

        // Create connection
        $this->conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        return $this->conn;

        if ($this->conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    }

    public function close() {
        //$this->connection();
        $this->conn->close();
    }

    /* Return Values in Array Variable */

    function executeArray($query) {
        try {
            $db = $this->connection();
            $sel_qry_exe = $db->query($query);
            $data = array();
            while ($fetch_data = $sel_qry_exe->fetch_array()) {
                $data[] = $fetch_data;
            }
            $this->close();
            return $data;
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    /* Return Single Value (String or Integer) */

    function executeQuery($query, $value) {
        try {
            $db = $this->connection();
            $sel_qry_exe = $db->query($query);
            $fetch_data = $sel_qry_exe->fetch_array();
            $this->close();
            return $fetch_data[$value];
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    public function executeObject($strQuery) {
        try {
            $db = $this->connection();
            $sel_qry_exe = $db->query($strQuery);
            $data = array();
            while ($fetch_data = $sel_qry_exe->fetch_object()) {
                $data[] = $fetch_data;
            }
            $this->close();
            return $data;
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    function executeAssoc($query) {
        try {
            $db = $this->connection();
            $sel_qry_exe = $db->query($query);
            $data = array();
            while ($fetch_data = $sel_qry_exe->fetch_assoc()) {
                $data[] = $fetch_data;
            }
            $this->close();
            return $data;
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    public function executeRow($strQuery) {
        try {
            //echo $query;
            $db = $this->connection();
            $sel_qry_exe = $db->query($strQuery);
            $fetch_data = $sel_qry_exe->fetch_array();
            #echo '<script>alert("fetch_data '.$fetch_data.'")</script>';
            $this->close();
            return $fetch_data;
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    public function executeRowAssoc($strQuery) {
        try {
            //echo $query;
            $db = $this->connection();
            $sel_qry_exe = $db->query($strQuery);
            $fetch_data = $sel_qry_exe->fetch_assoc();
            #echo '<script>alert("fetch_data '.$fetch_data.'")</script>';
            $this->close();
            return $fetch_data;
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    /* Insert,Update or Delete Query Execution in Database */

    function executeNonQuery($query) {
        try {
            // echo $query;
            $db = $this->connection();
            $res_Query_Status = $db->query($query);
            $this->close();
            if ($res_Query_Status == 1) {
                return TRUE;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    function executeNonQueryGetLastId($query) {
        try {
            // echo $query;
            $db = $this->connection();
            $res_Query_Status = $db->query($query);
            $last_id = $db->insert_id;
            $this->close();
            if ($res_Query_Status == 1) {
                return $last_id;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    function executeProcedure($query) {
        try {
            $db = $this->connection();
            $sel_qry_exe = $db->query($query);
            $data = array();
            $fetch_data = $sel_qry_exe->fetch_array();
            $this->close();
            return $fetch_data;
        } catch (Exception $e) {
            $this->close();
            echo $e->getMessage();
        }
    }

    public function getResponce($childNode, $arr, $response) {
        //$arr = $this->getMulidimensionArray($arrDetails);
        $cnnDetails = count($childNode);
        for ($arrValue = 0; $arrValue < count($arr); $arrValue++) {
            for ($i = 0; $i < $cnnDetails; $i++) {
                $details[$childNode[$i]] = htmlspecialchars($arr[$arrValue][$i]);
            }
            array_push($response[$this->getKey($response)], $details);
        }
        unset($userObj);
        $response["success"] = 1;
        return json_encode($response);
    }

    public function getResponceAll($childNode, $arr, $response, $res) {
        //$arr = $this->getMulidimensionArray($arrDetails);
        $cnnDetails = count($childNode);
        for ($arrValue = 0; $arrValue < count($arr); $arrValue++) {
            for ($i = 0; $i < $cnnDetails; $i++) {
                $details[$childNode[$i]] = htmlspecialchars($arr[$arrValue][$i]);
            }
            array_push($response[$res], $details);
        }
        unset($userObj);
        //$response["success"] = 1;
        return $response;
    }

    public function getKey($response) {
        $response1 = array_keys($response);
        return $response1[0];
    }

    public function getMulidimensionArray($arr) {
        $table_rows = $arr[0][1];
        $table_cols = $arr[0][2];
        $total_records = $table_rows * $table_cols;
        $resArr = array();
        for ($row_count = 3; $row_count <= $total_records + 2; $row_count = $row_count + $table_cols) {
            $col_count = $row_count;
            $subResArr = array();
            for ($i = 0; $i < $table_cols; $i++) {
                $subResArr[] = $arr[0][$col_count + $i];
            }
            $resArr[] = $subResArr;
        }
        return $resArr;
    }

    public function display_error($strError) {
        try {
            echo'<script>alert("Database Error:- ' . $strError . '")</script>';
        } catch (Exception $e) {
            $this->close();

            echo $e->getMessage();
        }
    }

    /* Get IP Address */

    public function getUserIP() {
        $client = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote = $_SERVER['REMOTE_ADDR'];

        if (filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }

        return $ip;
    }

    public function randomString($length = 5) {
        $str = "";
        $characters = array_merge(range('A', 'Z'), range('a', 'z'), range('0', '9'));
        $max = count($characters) - 1;
        for ($i = 0; $i < $length; $i++) {
            $rand = mt_rand(0, $max);
            $str .= $characters[$rand];
        }
        return $str;
    }

}

?>