<?php

require 'rb.php';

class clsORM {

    var $host = "localhost";
    var $username = "root";
    var $password = "test";
    var $database = "test"; /* tut_restapi */
    var $myconn;

    function connectToDatabase() {
        error_reporting(E_ALL ^ E_DEPRECATED);
        if (R::testConnection()) {
            // echo 'connected';
        } else {
            $this->myconn = R::setup('mysql:host=' . $this->host . ';dbname=' . $this->database . '', $this->username, $this->password);
            if (!$this->myconn) {
                die("Cannot connect to the database");
            } else {
                //echo 'connected';
            }
        }

//        return $this->myconn;
    }

    function closeConnection() {
        R::close();
    }

    /* Return Single Value (String or Integer) */

    public function executeQuery($strQuery, $value = "") {
        try {
            $this->connectToDatabase();
            $result_total_count = R::getCell($strQuery);
            $this->closeConnection();
            return $result_total_count;
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    /* Return Values in Array Variable */

    public function executeArray($strQuery) {
        try {
            $this->connectToDatabase();
            $result = R::getAll($strQuery);
            $this->closeConnection();
            return $result;
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    public function executeAssoc($strQuery) {
        try {
            $this->connectToDatabase();
            $result = R::getAssoc($strQuery);
            $this->closeConnection();
            return $result;
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    /* Select row */

    public function executeRow($strQuery) {
        try {
            $this->connectToDatabase();
            $result = R::getRow($strQuery);

            $this->closeConnection();
            return $result;
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    /* Insert,Update or Delete Query Execution in Database */

    public function executeNonQuery($strQuery) {
        try {
            $this->connectToDatabase();
            $res_Query_Status = R::exec($strQuery);
            if ($res_Query_Status == 1 || $res_Query_Status == 0) {
                return TRUE;
            } else {
                return FALSE;
            }
            $this->closeConnection();
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    public function getInsertID($strQuery) {
        try {
            $this->connectToDatabase();
            $res_Query_Status = R::exec($strQuery);
            $last_id = R::getInsertID();
            $this->closeConnection();
            if ($res_Query_Status == 1) {
                return $last_id;
            } else {
                return FALSE;
            }
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    public function executeNonQueryGetLastId($strQuery) {
        try {
            return $this->getInsertID($strQuery);
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    /**/

    public function executeProcedure($strQuery) {
        try {
            return $this->executeRow($strQuery);
        } catch (Exception $e) {
            $this->closeConnection();
            echo $e->getMessage();
        }
    }

    public function getResponce($childNode, $arr, $response) {
        //$arr = $this->getMulidimensionArray($arrDetails);
        $cnnDetails = count($childNode);
        for ($arrValue = 0; $arrValue < count($arr); $arrValue++) {
            for ($i = 0; $i < $cnnDetails; $i++) {
                $details[$childNode[$i]] = htmlspecialchars($arr[$arrValue][$i]);
            }
            array_push($response[$this->getKey($response)], $details);
        }
        unset($userObj);
        $response["success"] = 1;
        return json_encode($response);
    }

    public function getResponceAll($childNode, $arr, $response, $res) {
        //$arr = $this->getMulidimensionArray($arrDetails);
        $cnnDetails = count($childNode);
        for ($arrValue = 0; $arrValue < count($arr); $arrValue++) {
            for ($i = 0; $i < $cnnDetails; $i++) {
                $details[$childNode[$i]] = htmlspecialchars($arr[$arrValue][$i]);
            }
            array_push($response[$res], $details);
        }
        unset($userObj);
        //$response["success"] = 1;
        return $response;
    }

    public function getKey($response) {
        $response1 = array_keys($response);
        return $response1[0];
    }

    public function getMulidimensionArray($arr) {
        $table_rows = $arr[0][1];
        $table_cols = $arr[0][2];
        $total_records = $table_rows * $table_cols;
        $resArr = array();
        for ($row_count = 3; $row_count <= $total_records + 2; $row_count = $row_count + $table_cols) {
            $col_count = $row_count;
            $subResArr = array();
            for ($i = 0; $i < $table_cols; $i++) {
                $subResArr[] = $arr[0][$col_count + $i];
            }
            $resArr[] = $subResArr;
        }
        return $resArr;
    }

}

?>