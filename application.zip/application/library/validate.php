<?php

if (isset($_REQUEST['request']) && $_REQUEST['request'] == true) {
    $MethodStr = '';
    $selectmethod = 'REQUEST';
    $feilds = array_unique(array_merge($is_set_field, $not_empty_field, $is_numeric_field));
    foreach ($feilds as $feild) {
        $arr = explode('.', $feild);
        $count = count($arr);
        if ($count != 1) {
            $feild = $arr[1];
            $MethodStr = $MethodStr . "$" . $feild . " = " . "$" . "_" . $selectmethod . "['" . "$feild" . "'];" . "\n";
        } else {
            $MethodStr = $MethodStr . "$" . $feild . " = " . "$" . "_" . $selectmethod . "['" . "$feild" . "'];" . "\n";
        }
    }
    $feild = '';
    echo $MethodStr;
}

function CONVERT_DATE($date, $time_zone = '') {
    if ($time_zone == '' && empty($time_zone)) {
        return $date;
    }
    $operation = substr($time_zone, 0, 1);
    list($h, $m) = explode(':', substr($time_zone, 1));
    $modified_time = date('Y-m-d H:i:s', strtotime($operation . $m . "minutes", strtotime(date('Y-m-d H:i:s', strtotime($operation . $h . "hours", strtotime(date($date)))))));
    return $modified_time;
}

function CONVERT_DATE_FORMAT($date, $time_zone = '') {
    if ($time_zone == '' && empty($time_zone)) {
        $date = date('j-F-Y g:i A', strtotime($date));
        return $date;
    }
    $operation = substr($time_zone, 0, 1);
    list($h, $m) = explode(':', substr($time_zone, 1));
    $modified_time = date('j-F-Y g:i A', strtotime($operation . $m . "minutes", strtotime(date('Y-m-d H:i:s', strtotime($operation . $h . "hours", strtotime(date($date)))))));
    //$modified_date = date('j-F-Y g:i A', strtotime($modified_time));
    return $modified_time;
}

function CONVERT_ONLY_DATE($date, $time_zone = '') {
    if ($time_zone == '' && empty($time_zone)) {
        $date = date('j-F-Y', strtotime($date));
        return $date;
    }
    $operation = substr($time_zone, 0, 1);
    list($h, $m) = explode(':', substr($time_zone, 1));
    $modified_time = date('j-F-Y', strtotime($operation . $m . "minutes", strtotime(date('Y-m-d H:i:s', strtotime($operation . $h . "hours", strtotime(date($date)))))));
    //$modified_date = date('j-F-Y g:i A', strtotime($modified_time));
    return $modified_time;
}

function STRTOTIME_TO_DATE($date) {
    $modified_time = ($date != 0) ? date('Y-m-d H:i:s', $date) : 0;
    return $modified_time;
}

function LETTERS_AND_SPACE($name, $key = '') {
    if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
        $nameErr = "Only letters and white space allowed";
        $response['error'] = array("code" => 1, "status" => 400, "message" => $nameErr);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        die();
    }
    return $name;
}

function LETTERS($name, $key = '') {
    if (!preg_match("/^[a-zA-Z]*$/", $name)) {
        $nameErr = "Only letters allowed in " . $key;
        $response['error'] = array("code" => 1, "status" => 400, "message" => $nameErr);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        die();
    }
    return $name;
}

function ALPHANUMERIC($name, $key = '') {
    if (!preg_match('/^[a-zA-Z0-9]+/', $name)) {
        $nameErr = "Only alphanumeric allowed in " . $key;
        $response['error'] = array("code" => 1, "status" => 400, "message" => $nameErr);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        die();
    }
    return $name;
}

function EMAIL($email, $key = '') {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format in " . $key;
        $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        die();
    }
    return $email;
}

function CHECK_DATE($date) {

    if (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $date)) {
        $nameErr = "Input valid date format : YYYY-mm-dd";
        $response['error'] = array("code" => 1, "status" => 400, "message" => $nameErr);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        die();
    }
    return $date;
}

function is_set_field($required_fields = array(), $REQUEST) {
    if (count($required_fields) > 0) {
        $missing_fields = array();
        $missing = '';
        $flag = 0;
        foreach ($required_fields as $required_field) {
            if (!(isset($REQUEST[$required_field]))) {
                $missing_fields[] = $required_field;
                $flag = 1;
            }
        }
        if ($flag == 1) {
            $missing_field = implode(', ', $missing_fields);

            $message = rtrim($missing_field, ', ') . (count($missing_fields) > 1 ? ' are ' : ' is ') . 'required';
            $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            die();
        }
    }
}

function not_empty_field($required_fields = array(), $REQUEST) {
    if (count($required_fields) > 0) {
        $missing_fields = array();
        $required_field = '';
        $missing = '';
        $flag = 0;
        foreach ($required_fields as $required_field) {
            if (isset($REQUEST[$required_field]) && empty($REQUEST[$required_field])) {
                $missing_fields[] = $required_field;
                $flag = 1;
            }
        }
        if ($flag == 1) {
            $missing_field = implode(', ', $missing_fields);
            $message = rtrim($missing_field, ', ') . (count($missing_fields) > 1 ? ' are ' : ' is ') . 'not empty';
            $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            die();
        }
    }
}

function is_numeric_field($required_fields = array(), $REQUEST) {
    if (count($required_fields) > 0) {
        $missing_fields = array();
        $required_field = '';
        $missing = '';
        $flag = 0;
        foreach ($required_fields as $required_field) {
            if (!is_numeric($REQUEST[$required_field]) || $REQUEST[$required_field] < 0) {
                $missing_fields[] = $required_field;
                $flag = 1;
            }
        }
        if ($flag == 1) {
            $missing_field = implode(', ', $missing_fields);
            $message = rtrim($missing_field, ', ') . ' must be numeric.';
            $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            die();
        }
    }
}

function is_array_field($required_fields = array(), $REQUEST) {
    if (count($required_fields) > 0) {
        $missing_fields = array();
        $required_field = '';
        $missing = '';
        $flag = 0;
        foreach ($required_fields as $required_field) {
            if (!is_array($REQUEST[$required_field])) {
                $missing_fields[] = $required_field;
                $flag = 1;
            }
        }
        if ($flag == 1) {
            $missing_field = implode(', ', $missing_fields);
            $message = rtrim($missing_field, ', ') . ' must be array.';
            $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            die();
        }
    }
}

if (!empty($is_set_field)) {
    is_set_field($is_set_field, $_REQUEST);
}
if (!empty($not_empty_field)) {
    not_empty_field($not_empty_field, $_REQUEST);
}
if (!empty($is_numeric_field)) {
    is_numeric_field($is_numeric_field, $_REQUEST);
}
if (!empty($is_array_field)) {
    is_array_field($is_array_field, $_REQUEST);
}







