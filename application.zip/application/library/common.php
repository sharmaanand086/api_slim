<?php

class clsCommon {

    public function getUserIP() {
        $client = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote = $_SERVER['REMOTE_ADDR'];

        if (filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }

        return $ip;
    }

    public function encryptor($action, $string) {
        $PASS_KEY = 'EXIM';
        $string = $PASS_KEY . $string;
        $SECRET_KEY = 'gmUOP1qrmtsoCNEo';
        $SECRET_IV = 'iYEGtwdaZ8g4QEPv';
        $ENCRYPT_CODE = 'AES-256-CBC'; /* Do not change this */
        $output = false;
        $key = hash('sha256', $SECRET_KEY);
        $iv = substr(hash('sha256', $SECRET_IV), 4, 16);

        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $ENCRYPT_CODE, $key, 0, $iv);
            $output = base64_encode($output);
        } else if ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $ENCRYPT_CODE, $key, 0, $iv);
        }
        return $output;
    }
    
    

    function crypto_rand_secure($min, $max) {
        $range = $max - $min;
        if ($range < 1)
            return $min; // not so random...
        $log = ceil(log($range, 2));
        $bytes = (int) ($log / 8) + 1; // length in bytes
        $bits = (int) $log + 1; // length in bits
        $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
        do {
            $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
            $rnd = $rnd & $filter; // discard irrelevant bits
        } while ($rnd > $range);
        return $min + $rnd;
    }

    function getAlphanumericString($length) {
        $token = "";
        $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $codeAlphabet .= "abcdefghijklmnopqrstuvwxyz";
        $codeAlphabet .= "0123456789";
        $max = strlen($codeAlphabet); // edited

        for ($i = 0; $i < $length; $i++) {
            $token .= $codeAlphabet[$this->crypto_rand_secure(0, $max - 1)];
        }

        return $token;
    }

    public function custom_encryptor($action, $string, $PASS_KEY) {
        $string = $PASS_KEY . $string;
        $SECRET_KEY = 'gmUOP1qrmtsoCNEo';
        $SECRET_IV = 'iYEGtwdaZ8g4QEPv';
        $ENCRYPT_CODE = 'AES-256-CBC'; /* Do not change this */
        $output = false;
        $key = hash('sha256', $SECRET_KEY);
        $iv = substr(hash('sha256', $SECRET_IV), 4, 16);

        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $ENCRYPT_CODE, $key, 0, $iv);
            $output = base64_encode($output);
        } else if ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $ENCRYPT_CODE, $key, 0, $iv);
        }
        return $output;
    }

    public function strip_html_tags($text) {
        $text = preg_replace(
                array(
// Remove invisible content
            '@<script[^>]*?.*?</script>@siu',
            '@<p[^>]*?.*?</p>@siu',
            '@<object[^>]*?.*?</object>@siu',
            '@<applet[^>]*?.*?</applet>@siu',
            '@<noscript[^>]*?.*?</noscript>@siu',
                ), array(
            ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
            "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
            "\n\$0", "\n\$0",
                ), $text);
        return ($text);
    }

    public function check_number($numeric_value) {
        if (is_numeric($numeric_value)) {
            if ($numeric_value > 0) {
                return TRUE;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /* example: array("99999999999","211111111111","312434534545") */

    public function is_number($values) {
        if (is_array($values)) {
            foreach ($values as $a => $b) {
                if (is_numeric($b)) {
                    if ($b > 0) {
                        
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
            return true;
        } else {
            if ($this->check_number($values)) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    public function blocked_ip($ip, $intUserId, $lang = 'en') {
        $blocked_ips = array('192.36.96');
        if (in_array($ip, $blocked_ips)) {
            $response["code"] = "14";
            $response['error'] = $this->error_code(14, $lang);
            $this->addLog($ip, $intUserId, '', $response['error']['message'], 1, $lang);
            echo json_encode($response);
            die();
        } else {
            return TRUE;
        }
    }

    public function getExtension($str) {
        $i = strrpos($str, ".");
        if (!$i) {
            return "";
        }
        $l = strlen($str) - $i;
        $ext = substr($str, $i + 1, $l);
        return $ext;
    }

    public function xml2array($xmlObject, $out = array()) {
        foreach ((array) $xmlObject as $index => $node)
            $out[$index] = ( is_object($node) ) ? $this->xml2array($node) : $node;

        array_shift($out);
        return $out;
    }

    public function error_code($code, $lang) {
        $xml = simplexml_load_file("../xmldata/$lang/error_code.xml");
        $xmldata = $xml->xpath("code[@id='$code']");

        return (count($xmldata) > 0 ? ($this->xml2array($xmldata[0])) : array('code' => 0, 'status' => 0, 'message' => 'unknown'));
    }

    public function addLog($strIPAddress, $strUsername, $strFunctionName, $strMessage, $version, $lang) {
        try {

            date_default_timezone_set('Asia/Kolkata');
            $log = "Date and Time: " . date("F j, Y, g:i:s a") . PHP_EOL .
                    "IP Address: " . $strIPAddress . PHP_EOL .
                    "Username: " . $strUsername . PHP_EOL .
                    "Function Name: " . $strFunctionName . PHP_EOL .
                    "Version Name: " . $version . PHP_EOL .
                    "Message: " . $strMessage . PHP_EOL .
                    "Langauge: " . $lang . PHP_EOL .
                    "-----------------------------------------------------" . PHP_EOL;
            //Save string to log, use FILE_APPEND to append.

            file_put_contents('log/' . date("j.n.Y") . '.txt', $log, FILE_APPEND);
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function randomNumber($length) {
        $str = "";
        $characters = array_merge(range('0', '9'));
        $max = count($characters) - 1;
        for ($i = 0; $i < $length; $i++) {
            $rand = mt_rand(0, $max);
            $str .= $characters[$rand];
        }
        return $str;
    }

    public function checkfiletype($filetype, $lang) {
        if (!in_array(strtolower($filetype), array('gif', 'jpg', 'png', 'jpeg', 'pdf', 'doc', 'docx', 'xls', 'xlsx'))) {

            $response['error'] = $this->error_code(33, $lang);
            echo json_encode($response);
            die();
        }
    }

    public function send_mail_old($frommail, $from_name, $to_name, $to_email, $subject, $strMessage) {
        try {
            $strAuthKey = 'mnFUai48GdYDcgaD';
            $strCustomerNumber = '0406150520';
            /*  echo $email_status = $this->sms_email_status();
              if ($email_status->email_status == 1) { */
            require_once('lib/nusoap.php');
            $mail_obj = new nusoap_client('http://bewebservices.exioms.in/sendmail.asmx?WSDL', 'wsdl');

            $param_mail = array('strCustomerNumber' => $strCustomerNumber,
                'strAuthKey' => $strAuthKey,
                'intAppID' => '1', 'strSubject' => $subject,
                'strFromEmail' => $frommail, 'strFromName' => $from_name,
                'strToEmail' => $to_email, 'strToName' => $to_name,
                'strMessage' => $strMessage,
                'intSource' => '1',
                'strComment' => '');
            //print_r($param_mail)."<br/>";

            $result_mail = $mail_obj->call('SendTransactionalMailAPI', $param_mail, "http://tempuri.org/", "http://tempuri.org/");
            $status_mail = $result_mail['SendTransactionalMailAPIResult'];
            #echo '<script>alert("'.$status_mail.'");</script>';
            if ($status_mail == 'E-mail has been successfully sent.') {
                return true;
            } else {
                return false;
            }
            unset($mail_obj);
            #echo "Return status ".$status_mail;
            # }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
    public function send_mail($frommail, $from_name, $to_name, $to_email, $subject, $strMessage) {
        try {
            $strAuthKey = 'mnFUai48GdYDcgaD';
            $strCustomerNumber = '0406150520';
            /*  echo $email_status = $this->sms_email_status();
              if ($email_status->email_status == 1) { */
            require_once('lib/nusoap.php');
            $frommail="support@coachtofortune.com";
            $from_name='Support';
            
            $mail_obj = new nusoap_client('http://bewebservices.exioms.in/SendMail.asmx?WSDL', 'wsdl');

            $param_mail = array('strCustomerNumber' => $strCustomerNumber,
                'strAuthKey' => $strAuthKey,
                'intAppID' => '1', 'strSubject' => $subject,
                'strFromEmail' => $frommail, 'strFromName' => $from_name,
                'strToEmail' => $to_email, 'strToName' => $to_name,
                'strMessage' => $strMessage,
                'intSource' => '1',
                'strToken' => 'hslrhglsw629ls',
                'strComment' => '');
            //print_r($param_mail)."<br/>";

            $result_mail = $mail_obj->call('SendMailTransaction5', $param_mail, "http://tempuri.org/", "http://tempuri.org/");
            $status_mail = $result_mail['SendMailTransaction5Result'];
            #echo '<script>alert("'.$status_mail.'");</script>';
            if ($status_mail == 'E-mail has been successfully sent.') {
                return true;
            } else {
                return false;
            }
            unset($mail_obj);
            #echo "Return status ".$status_mail;
            # }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function send_msg($mobile, $strMessage) {
        try {
            return true;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function is_set_field($required_fields, $REQUEST) {
        if (count($required_fields) > 0) {
            $missing_fields = array();
            $missing = '';
            $flag = 0;
            foreach ($required_fields as $required_field) {
                if (!(isset($REQUEST[$required_field]))) {
                    $missing_fields[] = $required_field;
                    $flag = 1;
                }
            }
            if ($flag == 1) {
                $missing_field = implode(', ', $missing_fields);

                $message = rtrim($missing_field, ', ') . (count($missing_fields) > 1 ? ' are ' : ' is ') . 'required';
                $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                die();
            }
        }
    }

    public function not_empty_field($required_fields, $REQUEST) {
        if (count($required_fields) > 0) {
            $missing_fields = array();
            $required_field = '';
            $missing = '';
            $flag = 0;
            foreach ($required_fields as $required_field) {
                if (isset($REQUEST[$required_field]) && empty($REQUEST[$required_field])) {
                    $missing_fields[] = $required_field;
                    $flag = 1;
                }
            }
            if ($flag == 1) {
                $missing_field = implode(', ', $missing_fields);
                $message = rtrim($missing_field, ', ') . (count($missing_fields) > 1 ? ' are ' : ' is ') . 'not empty';
                $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                die();
            }
        }
    }

    public function is_numeric_field($required_fields, $REQUEST) {
        if (count($required_fields) > 0) {
            $missing_fields = array();
            $required_field = '';
            $missing = '';
            $flag = 0;
            foreach ($required_fields as $required_field) {
                if (!is_numeric($REQUEST[$required_field])) {
                    $missing_fields[] = $required_field;
                    $flag = 1;
                }
            }
            if ($flag == 1) {
                $missing_field = implode(', ', $missing_fields);
                $message = rtrim($missing_field, ', ') . ' must be numeric.';
                $response['error'] = array("code" => 1, "status" => 400, "message" => $message);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                die();
            }
        }
    }

    public function search($searchArray, $query, $order) {
        $strQuery = '';
        $strWh = '';
        $arrCount = count($searchArray);
        $limit = ($arrCount / 3);
        for ($i = 0; $i < $limit; $i++) {
            if ($searchArray[3 * $i] != "") {
                $col = 3 * $i + 1;
                $ch = 3 * $i + 2;
                switch ($searchArray[$ch]) {
                    case 1:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " LIKE \"%" . $searchArray[3 * $i] . "%\""; /* 1 For Like */
                        break;
                    case 2:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " = " . $searchArray[3 * $i] . ""; /* 2 For = */
                        break;
                    case 3:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " >= '" . $searchArray[3 * $i] . "'"; /* 3 For >= */
                        break;
                    case 4:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " <= '" . $searchArray[3 * $i] . "'"; /* 4 For <= */
                        break;
                    case 5:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " BETWEEN " . $searchArray[3 * $i] . ""; /* 5 For BETWEEN */
                        break;
                    case 6:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " IN (" . $searchArray[3 * $i] . ")"; /* 5 For IN */
                        break;
                    case 7:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " NOT IN (" . $searchArray[3 * $i] . ")"; /* 5 For IN */
                        break;
                    case 8:
                        $strWh = $strWh . " AND (" . $searchArray[$col][0] . " LIKE \"%" . $searchArray[3 * $i] . "%\" OR " . $searchArray[$col][1] . " LIKE \"%" . $searchArray[3 * $i] . "%\")"; /* 8 OR = */
                        break;
                    default:
                        $strWh = $strWh . '';
                        break;
                }
            }
        }


        $strQuery = $query . $strWh . $order;

        return $strQuery;
    }

    public function get_query($searchArray) {
        $strQuery = '';
        $strWh = '';
        $arrCount = count($searchArray);
        $limit = ($arrCount / 3);
        for ($i = 0; $i < $limit; $i++) {
            if ($searchArray[3 * $i] != "") {
                $col = 3 * $i + 1;
                $ch = 3 * $i + 2;
                switch ($searchArray[$ch]) {
                    case 1:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " LIKE \"%" . $searchArray[3 * $i] . "%\""; /* 1 For Like */
                        break;
                    case 2:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " = " . $searchArray[3 * $i] . ""; /* 2 For = */
                        break;
                    case 3:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " >= '" . $searchArray[3 * $i] . "'"; /* 3 For >= */
                        break;
                    case 4:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " <= '" . $searchArray[3 * $i] . "'"; /* 4 For <= */
                        break;
                    case 5:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " BETWEEN " . $searchArray[3 * $i] . ""; /* 5 For BETWEEN */
                        break;
                    case 6:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " IN (" . $searchArray[3 * $i] . ")"; /* 5 For IN */
                        break;
                    case 7:
                        $strWh = $strWh . " AND " . $searchArray[$col] . " NOT IN (" . $searchArray[3 * $i] . ")"; /* 5 For IN */
                        break;
                    default:
                        $strWh = $strWh . '';
                        break;
                }
            }
        }
        $strQuery = $strWh;
        return $strQuery;
    }

}

?>