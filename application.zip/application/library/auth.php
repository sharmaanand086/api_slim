<?php

class clsAuth {

    public function checkUser($userid) {
        try {
            include_once "../../library/ORM.php";
            $objORM = new clsORM();
            $useridcount = $objORM->executeQuery("SELECT count(1) as userExist FROM user_login where active=1 AND userid=$userid", "userExist");
            return $useridcount;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function checkToken($userid, $token, $ip, $lang) {
        try {
            include_once "../../library/ORM.php";
            $objORM = new clsORM();
            $tokenExist = $objORM->executeQuery("SELECT count(1) as tokenExist FROM user where softdelete=0 AND user_id=$userid AND token='$token'", "tokenExist");
            if ($tokenExist == 0) {
                include_once "../../library/common.php";
                $objCommon = new clsCommon();
                $response['query'] = "SELECT count(1) as tokenExist FROM user where softdelete=0 AND user_id=$userid AND token='$token'";
                $response['error'] = $objCommon->error_code(5, $lang);
                //$objCommon->addLog($ip, $userid, '', $response['error']['message'], 1, $lang);
                //$this->logout($userid);
                echo json_encode($response);
                die();
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function checkApiFlag($ip, $userid, $lang) {
        try {

            $xml = simplexml_load_file("../xmldata/path.xml");
            $apiflag = $xml->apiflag;
            if ($apiflag == 0) {
                include_once "common.php";
                $objCommon = new clsCommon();
                $response['error'] = $objCommon->error_code(15, $lang);
                $objCommon->addLog($ip, $userid, '', $response['error']['message'], 1, $lang);
                echo json_encode($response);
                //$this->logout($userid);
                die();
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function checkOtherAndroidLogin($userid, $gcmRegId) {
        try {
            include_once "ORM.php";
            $objORM = new clsORM();
            $gcmOldId = $objORM->executeQuery("SELECT gcmid FROM user_login where active=1 AND userid=$userid", "gcmid");
            $objORM->executeNonQuery("UPDATE user_login SET `gcmid` = '' WHERE userid !=$userid AND `gcmid` = '$gcmRegId'");

            if ($gcmRegId != $gcmOldId && $gcmOldId != '') {
                // echo 'Not match force logout other device.';
                $credentials = $objORM->executeArray("SELECT a.`gcmid`, b.`key` FROM `user_login` a INNER JOIN keys_master b on(b.userid=a.parent_id) WHERE a.`userid`='$userid' AND b.`active` =1");
                $gcmid = $credentials[0][0];
                $key = $credentials[0][0];
                $message = array("body" => "1");
                $this->send_notification_firebase($key, $gcmOldId, $message);
            }
            $objORM->executeNonQuery("UPDATE user_login SET `gcmid` = '$gcmRegId' WHERE userid=$userid");
            return TRUE;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function logout($userid) {
        try {
            $response = array();
            include_once "ORM.php";
            $objORM = new clsORM();
            $credentials = $objORM->executeArray("SELECT a.`gcmid`, b.`key` FROM `user_login` a INNER JOIN keys_master b on(b.userid=a.parent_id) WHERE a.`userid`='$userid' AND b.`active` =1");
            $gcmid = $credentials[0][0];
            $key = $credentials[0][0];
            // $gcmid = $objORM->executeQuery("SELECT gcmid as gcmid FROM `user_login` where userid='$userid'", "gcmid");
            $message = array("body" => "1");
            $result = $this->send_notification_firebase($key, $gcmid, $message);
            //return true;
        } catch (Exception $e) {
            echo json_encode($response);
        }
    }

    public function send_notification($registatoin_ids, $message) {
        define("GOOGLE_API_KEY", "AIzaSyBFsaRTmCnHebIbrodBskiRmCuVxTFFY_U"); // Place your Google API Key

        $url = 'https://android.googleapis.com/gcm/send';  // Set POST variables

        $fields = array('registration_ids' => $registatoin_ids, 'data' => $message,);

        $headers = array('Authorization: key=' . GOOGLE_API_KEY, 'Content-Type: application/json');

        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        // echo $result;
    }

    public function send_notification_firebase($key, $registrationIds, $msg) {

        #API access key from Google API's Console
        define('API_ACCESS_KEY', 'AIzaSyBkEEOVJdNBSWTSTTvLXsk8ZXqjrA4O0j8');

        /* $msg = array
          (
          'body' => 'Body  Of Notification',
          'title' => 'Title Of Notification',
          'icon' => 'myicon',
          'sound' => 'mySound'
          );
         */
        $fields = array('to' => $registrationIds, 'notification' => $msg);
        $headers = array('Authorization: key=' . API_ACCESS_KEY, 'Content-Type: application/json');

        #Send Reponse To FireBase Server	
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);

        #Echo Result Of FireBase Server
        // echo $result;
    }

    public function checkApiKeyExist($api_key, $userid, $ip, $lang) {
        try {
            include_once '../../library/ORM.php';
            $objORM = new clsORM();
            include_once "../../library/common.php";
            $objCommon = new clsCommon();
            $api_key_count = $objORM->executeQuery("SELECT count(1) as keyExist FROM api_keys where status=0 AND api_key='$api_key'", "keyExist");
            $objORM->executeNonQuery("UPDATE api_keys SET status=1 where status=0 AND api_key='$api_key'");

            if ($api_key_count == 1) {
                return TRUE;
            } else {
                $response['error'] = $objCommon->error_code(4, $lang);
                //echo ""
                $objCommon->addLog($ip, $userid, $api_key, $response['error']['message'], 1, $lang);
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                //$this->logout($userid);
                die();
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function send_sms($mobile, $strmessage) {
        try {
            $credentials = $objORM->executeRow("SELECT `sms_authkey`, `sms_senderid` FROM `sms_email_credentials` WHERE id=1");
            //$sms_status = $this->sms_email_status();/*Global Status*/
            // if ($sms_status->sms_status == 1) {
            $authkey = $credentials['sms_authkey'];
            $senderid = $credentials['sms_senderid'];
            $curl_post_data = array(
                'authkey' => $authkey,
                'campaign' => 'API',
                'senderid' => $senderid,
                'route' => '1',
                'message' => $strmessage,
                'number' => $mobile
            );
            //print_r($curl_post_data);
            $querystring = http_build_query($curl_post_data);
            $curl = curl_init();

            $url = "http://bsapp.exioms.com/api/sendsinglesms.php?$querystring";
            curl_setopt_array($curl, array(
                CURLOPT_URL => "$url",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
                return FALSE;
            } else {
                return TRUE;
            }
            // }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function get_attachment($msg_id) {
        include_once '../../library/ORM.php';
        $objORM = new clsORM();
        $data = $objORM->executeArray("SELECT attachment FROM `ticket_message_attachment_details`  WHERE active = 1 AND ticket_message_id='$msg_id'");
        return $data;
    }

}

?>