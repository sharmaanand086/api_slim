<?php 
ob_start();
session_start();
include_once 'ORM.php';
include_once 'common.php';
include_once 'auth.php';
require_once 'validate.php';
include_once 'sendmail.php'; 

$objORM = new clsORM();
$objCommon = new clsCommon();
$objAuth = new clsAuth();

$objSendmail = new clsSendmail();

$arr_lang = array('en', 'fr');
/* Date Time */
date_default_timezone_set('Asia/Calcutta');
$todays_date = date("Y-m-d H:i:s");
$date = date("Y-m-d");
define('TODAYS_DATE', $todays_date);
define('DATE', $date);
define('LIMIT', 20);


define('INR_AMOUNT', 1000);
define('USD_AMOUNT', 690); 

/* application Path */
//$xml = simplexml_load_file("../template/path.xml");
$application_path = "http://$_SERVER[HTTP_HOST]" . "/c2f/coachinghub/";
$headers = getallheaders();
//$api_key = isset($headers['api_key'])?$headers['api_key']:'';
$token = isset($headers['Token']) ? $headers['Token'] : '';

//$api_key = isset($_REQUEST['api_key']) ? $_REQUEST['api_key'] : '';
//$token = isset($_REQUEST['token']) ? $_REQUEST['token'] : '';
$ip_address = isset($_REQUEST['ip_address']) ? $_REQUEST['ip_address'] : '';
$intUserId = isset($_REQUEST['intUserId']) ? $_REQUEST['intUserId'] : '';
$lang = (isset($headers['App-Lang']) && $headers['App-Lang'] != '' && in_array($headers['App-Lang'], $arr_lang)) ? $headers['App-Lang'] : 'en';

(isset($_REQUEST['validate']) ? print_r($_REQUEST) : '');

//$api_flag = $objAuth->checkApiFlag($ip_address, $intUserId, $lang);

$ip_status = $objCommon->blocked_ip($ip_address, $intUserId, $lang);

//(($api_key != '') ? $objAuth->checkApiKeyExist($api_key, $intUserId, $ip_address, $lang) : '');

(($token != '' && $intUserId != '') ? $objAuth->checkToken($intUserId, $token, $ip_address, $lang) : '');
?>