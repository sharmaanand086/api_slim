<?php

class clsSendmail {

     public function registeredUserContaint($name,$email,$password) {
            date_default_timezone_set('Europe/London');
            $date = date('Y-m-d H:i:s');
            $newfile = '../../emailer/register.html';
            $file = '../../emailer/register1.html';
            if (!copy($file, $newfile)) {
                 //echo "failed to copy file...\n";
            } else {
                //echo "copy file success \n";
            }
            $path_to_file = '../../emailer/register.html';
            $file_contents = file_get_contents($path_to_file);
            
            $file_contents = str_replace("&&mailto&&", $name, $file_contents);
            $file_contents = str_replace("&&email&&", $email, $file_contents);
            $file_contents = str_replace("&&password&&", $password, $file_contents);
            $file_contents = str_replace("&&date&&", $date, $file_contents);
            file_put_contents($path_to_file, $file_contents);
            #$path_to_file = '../admin/project_mailer.php';
            $file_contents = file_get_contents($path_to_file);
            $message = $file_contents;
            return $message;
    }
    
}

?>